/**
 * Author: Kailash kumar
 */

 /**
  * Constant for application actions
  */
  export const USER_LOGIN = "USER_LOGIN";