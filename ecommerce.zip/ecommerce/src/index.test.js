import expect from 'expect';

describe('company module', () => {
    it('should pass', () => {
        expect(true).toEqual(true);
    });
});