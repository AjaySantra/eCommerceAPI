/**
 * Author: Kailash kumar
 */

/*
* initialStates passed in reducers. It indicates the basic structure of Redux store.
* */
export default {
    user: {}
};
