"use strict";

var logger = require("./logger");

/**
 * Get Product list ()
 */


/**
 * Get Product details (productID)
 */
